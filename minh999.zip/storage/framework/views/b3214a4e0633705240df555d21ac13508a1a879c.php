<?php echo $__env->make('teamplte.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <!-- DataTables -->
  <style type="text/css">
    #example1_filter {
      float: right;
    }
    #example1_paginate {
      text-align: right;
    }
    #example1_paginate .pagination {
      margin: 0px;
    }
    .btn-block {
      max-width: 120px;
    }
  </style>
  <!-- Left side column. contains the logo and sidebar -->
<?php echo $__env->make('teamplte.slidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <link rel="stylesheet" href="bower_components/morris.js/morris.css">
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Đơn xin vay
        <small>Chúc mừng năm mới</small>
      </h1>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-12">
          <div class="box box-warning">
            <div class="box-header">
              <h3 class="box-title">Đơn xin vay</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>#</th>
                  <th>Tên shop</th>
                  <th>Tên khách hàng</th>
                  <th>Số điện thoại</th>
                  <th>Chứng minh thư</th>
                  <th style="text-align: right;">Số tiền cần vay</th>
                  <th style="text-align: center;">Số ngày vay</th>
                  <th style="text-align: center;">Trạng thái</th>
                  <th style="text-align: center;">Giải ngân</th>
                  <th style="text-align: center;">Đã thêm</th>
                  <th style="max-width: 70px"></th>
                </tr>
                </thead>
                <tbody>
                <?php if(isset($idshop)): ?>
                  <?php $__currentLoopData = $idshop; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ids): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php $__currentLoopData = $shophoso; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shophs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($shophs->idmember == $ids->id): ?>
                  <tr>
                    <td><?php echo e($shophs->id); ?></td>
                    <td>
                      <?php $__currentLoopData = $nameshop; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $names): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if($shophs->idmember == $names->id): ?>
                      <?php echo e($names->name); ?>

                      <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                    <td>
                      <?php echo e($shophs->hoten); ?>

                    </td>
                    <td><?php echo e($shophs->sdt); ?></td>
                    <td><?php echo e($shophs->cmt); ?></td>
                    <td style="text-align: right;"><?= number_format($shophs->sotienvay,0,",","."); ?> <b> đ</b></td>
                    <td style="text-align: center;"><?php echo e($shophs->songay); ?></td>
                    <td style="text-align: center;">
                      <?php $__currentLoopData = $trangthaihoso; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tths): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($shophs->trangthaihopdong == 1 && $shophs->trangthaihopdong == $tths->id): ?>
                        <span class="label label-warning"><?php echo e($tths->name); ?></span>
                        <?php elseif($shophs->trangthaihopdong == 2 && $shophs->trangthaihopdong == $tths->id): ?>
                        <span class="label label-success"><?php echo e($tths->name); ?></span>
                        <?php elseif($shophs->trangthaihopdong == 5 && $shophs->trangthaihopdong == $tths->id): ?>
                        <span class="label label-danger"><?php echo e($tths->name); ?></span>
                        <?php elseif($shophs->trangthaihopdong == $tths->id): ?>
                        <span class="label label-primary"><?php echo e($tths->name); ?></span>
                        <?php endif; ?> 
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                    <td style="text-align: center;">
                      <?php if($shophs->giaingan < 1): ?>
                        <span class="label label-primary">Chưa giải ngân</span>
                      <?php else: ?>
                        <span class="label label-success">Đã giải ngân</span>
                      <?php endif; ?>
                    </td>
                    <td style="text-align: center;"><?php echo e(substr($shophs->created_at,0,10)); ?></td>
                    <?php if(Auth::user()->rule != 7): ?>
                    <th>
                      <a href="<?php echo e(url('hoadonshop')); ?>/<?php echo e($shophs->id); ?>">
                        <button type="button" class="btn btn-block btn-default">Chi tiết</button>
                      </a>
                      <?php if(Auth::user()->rule <3): ?>
                      <?php if($shophs->giaingan == 1): ?>
                      <a href="<?php echo e(url('giaingan')); ?>/<?php echo e($shophs->id); ?>">
                        <button type="button" class="btn btn-block btn-danger">Hủy giải ngân</button>
                      </a>
                      <?php endif; ?>
                      <?php endif; ?>
                    </th>
                    <?php endif; ?>
                    <?php if(Auth::user()->rule == 7): ?>
                    <?php if($shophs->giaingan == 0): ?>
                    <th>
                      <a href="<?php echo e(url('giaingan')); ?>/<?php echo e($shophs->id); ?>">
                        <button type="button" class="btn btn-block btn-success">Giải ngân</button>
                      </a>
                    </th>
                    <?php endif; ?>
                    <?php endif; ?>
                  </tr>
                  <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                  <?php $__currentLoopData = $shophoso; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shophs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($shophs->id); ?></td>
                    <td>
                      <?php $__currentLoopData = $nameshop; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $names): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if($shophs->idmember == $names->id): ?>
                      <?php echo e($names->name); ?>

                      <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                    <td>
                      <?php echo e($shophs->hoten); ?>

                    </td>
                    <td><?php echo e($shophs->sdt); ?></td>
                    <td><?php echo e($shophs->cmt); ?></td>
                    <td style="text-align: right;"><?= number_format($shophs->sotienvay,0,",","."); ?> <b> đ</b></td>
                    <td style="text-align: center;"><?php echo e($shophs->songay); ?></td>
                    <td style="text-align: center;">
                      <?php $__currentLoopData = $trangthaihoso; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tths): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($shophs->trangthaihopdong == 1 && $shophs->trangthaihopdong == $tths->id): ?>
                        <span class="label label-warning"><?php echo e($tths->name); ?></span>
                        <?php elseif($shophs->trangthaihopdong == 2 && $shophs->trangthaihopdong == $tths->id): ?>
                        <span class="label label-success"><?php echo e($tths->name); ?></span>
                        <?php elseif($shophs->trangthaihopdong == 5 && $shophs->trangthaihopdong == $tths->id): ?>
                        <span class="label label-danger"><?php echo e($tths->name); ?></span>
                        <?php elseif($shophs->trangthaihopdong == $tths->id): ?>
                        <span class="label label-primary"><?php echo e($tths->name); ?></span>
                        <?php endif; ?> 
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                    <td style="text-align: center;">
                      <?php if($shophs->giaingan < 1): ?>
                        <span class="label label-primary">Chưa giải ngân</span>
                      <?php else: ?>
                        <span class="label label-success">Đã giải ngân</span>
                      <?php endif; ?>
                    </td>
                    <td style="text-align: center;"><?php echo e(substr($shophs->created_at,0,10)); ?></td>
                    <?php if(Auth::user()->rule != 7): ?>
                    <th>
                      <a href="<?php echo e(url('hoadonshop')); ?>/<?php echo e($shophs->id); ?>">
                        <button type="button" class="btn btn-block btn-default">Chi tiết</button>
                      </a>
                      <?php if(Auth::user()->rule <3): ?>
                      <?php if($shophs->giaingan == 1): ?>
                      <a href="<?php echo e(url('giaingan')); ?>/<?php echo e($shophs->id); ?>">
                        <button type="button" class="btn btn-block btn-danger">Hủy giải ngân</button>
                      </a>
                      <?php endif; ?>
                      <?php endif; ?>
                    </th>
                    <?php endif; ?>
                    <?php if(Auth::user()->rule == 7): ?>
                    <?php if($shophs->giaingan == 0): ?>
                    <th>
                      <a href="<?php echo e(url('giaingan')); ?>/<?php echo e($shophs->id); ?>">
                        <button type="button" class="btn btn-block btn-success">Giải ngân</button>
                      </a>
                    </th>
                    <?php endif; ?>
                    <?php endif; ?>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
        </div>
      </div>
    </section>
    <!-- /.content -->
  </div>
  <footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 1.0
    </div>
    <strong>Dương Văn Minh</strong>
  </footer>

  <!-- Control Sidebar -->
  
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="<?php echo e(url('')); ?>/bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="<?php echo e(url('')); ?>/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- DataTables -->
<script src="<?php echo e(url('')); ?>/bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?php echo e(url('')); ?>/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<!-- Slimscroll -->
<script src="<?php echo e(url('')); ?>/bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="<?php echo e(url('')); ?>/bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo e(url('')); ?>/dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo e(url('')); ?>/dist/js/demo.js"></script>
<!-- page script -->
<script>
  $(function () {
    $('#example1').DataTable()
  })
</script>
</body>
</html>

<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">
<?php echo $__env->make('teamplte.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <!-- DataTables -->
  <style type="text/css">
    #example1_filter {
      float: right;
    }
    #example1_paginate {
      text-align: right;
    }
    #example1_paginate .pagination {
      margin: 0px;
    }
    .nutbox {
      font-weight: bold;
      border: #fff;
      color: #00a65a;
      background-color: #fff;
      padding: 0px 4px;
    }
    .dataTables_length {
      display: none;
    }
    .pagination {
      float: right;
    }
  </style>
  <!-- Left side column. contains the logo and sidebar -->
<?php echo $__env->make('teamplte.slidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Đơn xin vay
        <small>Chúc mừng năm mới</small>
      </h1>
    </section>
    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-12">
          <?php if( session()->has('message') ): ?>
              <div id="delay3s" class="alert alert-dismissable" style="color: #fff;background-color: #00a65a">
                  <i class="fa fa-warning"></i>
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <b>Thông báo!</b> <?php echo e(session()->get('message')); ?>

              </div>
          <?php endif; ?>
          <?php if( session()->has('danger') ): ?>
              <div id="delay3s" class="alert alert-danger alert-dismissable">
                  <i class="fa fa-warning"></i>
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <b>Thông báo!</b> <?php echo e(session()->get('danger')); ?>

              </div>
          <?php endif; ?>
          <div class="box box-warning">
            <div class="box-header">
              <h3 class="box-title">Đơn xin vay</h3>
              <div class="box-tools pull-right">
                <?php if(isset($checkmem)): ?>
                <select class="form-control" name="user" style="float: left;width: 150px;margin-right: 15px;" id="optionnv">
                  <option>Chọn nhân viên</option>
                  <?php $__currentLoopData = $checkmem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($usr->id); ?>"><?php echo e($usr->hoten); ?> 
                    (
                      <?php $__currentLoopData = $chucvu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chucv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if($chucv->id == $usr->rule): ?>
                      <?php echo e($chucv->name); ?>

                      <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    )</option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <button type="button" class="btn-default btn" onclick="submitform()" >Phân quyền</button>
                <?php endif; ?>
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table class="table table-bordered table-hover">
                <thead>
                <tr>
                  <th style="width: 45px;"><button class="nutbox" onclick="allclick()">All</button></th>
                  <th>Tên khách hàng</th>
                  <th style="width: 200px">Nhân viên sử lý</th>
                  <th>Loại hình</th>
                  <th>Số tiền cần vay</th>
                  <th>Số ngày vay</th>
                  <th style="text-align: center;">Trạng thái</th>
                  <!-- <th style="text-align: center;">Đã vay</th> -->
                  <th>Thời gian</th>
                  <th></th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $hoso; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(Auth::user()->rule == 6 || Auth::user()->rule == 3): ?>
                  <?php $__currentLoopData = $nhanvien_donvay; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nvdv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($hs->id == $nvdv->idhoso && $nvdv->idnhanvien == Auth::user()->id): ?>
                  <tr>
                    <td><?php echo e($hs->id); ?></td>
                    <?php $__currentLoopData = $member; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($hs->idmember == $mb->id): ?>
                    <td>
                      <a href="<?php echo e(url('chitietkhachhang')); ?>/<?php echo e($mb->id); ?>"><?php echo e($mb->hoten); ?></a>
                    </td>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <td>
                      <?php $__currentLoopData = $nhanvien_donvay; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nvsl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($nvsl->idhoso == $hs->id): ?>
                          <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($nvsl->idnhanvien == $usse->id): ?>
                            <span class="label label-default"><?php echo e($usse->hoten); ?></span>
                            <?php endif; ?>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                    <td>Vay trả góp</td>
                    <td><?= number_format($hs->sotienvay,0,",","."); ?> <b> đ</b></td>
                    <td><?php echo e($hs->songay); ?></td>
                    <td style="text-align: center;">
                      <?php $__currentLoopData = $trangthaihoso; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tths): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($hs->trangthaihopdong == 1 && $hs->trangthaihopdong == $tths->id): ?>
                        <span class="label label-warning"><?php echo e($tths->name); ?></span>
                        <?php elseif($hs->trangthaihopdong == 2 && $hs->trangthaihopdong == $tths->id): ?>
                        <span class="label label-success"><?php echo e($tths->name); ?></span>
                        <?php elseif($hs->trangthaihopdong == 5 && $hs->trangthaihopdong == $tths->id): ?>
                        <span class="label label-danger"><?php echo e($tths->name); ?></span>
                        <?php elseif($hs->trangthaihopdong == $tths->id): ?>
                        <span class="label label-primary"><?php echo e($tths->name); ?></span>
                        <?php endif; ?> 
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <!-- <td style="text-align: center;">
                      Lần <?php echo e($hs->stt); ?>

                    </td> -->
                    <td><?php echo e(date('d-m-Y', strtotime($hs->created_at))); ?></td>
                    <th>
                      <a href="<?php echo e(url('hoadon')); ?>/<?php echo e($hs->id); ?>">
                        <button type="button" class="btn btn-block btn-default">Chi tiết</button>
                      </a>
                    </th>
                  </tr>
                  <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                  <tr onclick="checkbox(<?php echo e($hs->id); ?>)" name="trclick" style="cursor: pointer;">
                    <td>
                      <button class="nutbox" id="checkbox<?php echo e($hs->id); ?>"><span class='fa fa-square-o'></span></button>
                    </td>
                    <?php $__currentLoopData = $member; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($hs->idmember == $mb->id): ?>
                    <td>
                      <a href="<?php echo e(url('chitietkhachhang')); ?>/<?php echo e($mb->id); ?>"><?php echo e($mb->hoten); ?></a>
                    </td>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <td>
                      <?php $__currentLoopData = $nhanvien_donvay; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nvsl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($nvsl->idhoso == $hs->id): ?>
                          <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($nvsl->idnhanvien == $usse->id): ?>
                            <span class="label label-default"><?php echo e($usse->hoten); ?></span>
                            <?php endif; ?>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                    <td>Vay trả góp</td>
                    <td><?= number_format($hs->sotienvay,0,",","."); ?> <b> đ</b></td>
                    <td><?php echo e($hs->songay); ?></td>
                    <td style="text-align: center;">
                      <?php $__currentLoopData = $trangthaihoso; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tths): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($hs->trangthaihopdong == 1 && $hs->trangthaihopdong == $tths->id): ?>
                        <span class="label label-warning"><?php echo e($tths->name); ?></span>
                        <?php elseif($hs->trangthaihopdong == 2 && $hs->trangthaihopdong == $tths->id): ?>
                        <span class="label label-success"><?php echo e($tths->name); ?></span>
                        <?php elseif($hs->trangthaihopdong == 5 && $hs->trangthaihopdong == $tths->id): ?>
                        <span class="label label-danger"><?php echo e($tths->name); ?></span>
                        <?php elseif($hs->trangthaihopdong == $tths->id): ?>
                        <span class="label label-primary"><?php echo e($tths->name); ?></span>
                        <?php endif; ?> 
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <!-- <td style="text-align: center;">
                      Lần <?php echo e($hs->stt); ?>

                    </td> -->
                    <td><?php echo e(date('d-m-Y', strtotime($hs->created_at))); ?></td>
                    <th>
                      <a href="<?php echo e(url('hoadon')); ?>/<?php echo e($hs->id); ?>">
                        <button type="button" class="btn btn-block btn-default">Chi tiết</button>
                      </a>
                    </th>
                  </tr>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
            <div class="box-footer clearfix">
              <?php echo e($hoso->links()); ?>

            </div>
            <!-- /.box-body -->
          </div>
        </div>
      </div>
    </section>
    <!-- /.content -->
  </div>
<form class="form-horizontal" role="form" method="post" id="formtrangthai" action="<?php echo e(route('addmemhoso')); ?>">
  <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
  <input type="hidden" id="nhanbox" name="hosovalue">
  <input type="hidden" id="nhanbox2" name="memvalue">
</form>
  <footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 1.0
    </div>
    <strong>Dương Văn Minh</strong>
  </footer>

  <!-- Control Sidebar -->
  
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="<?php echo e(url('')); ?>/bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="<?php echo e(url('')); ?>/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- DataTables -->
<script src="<?php echo e(url('')); ?>/bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?php echo e(url('')); ?>/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<!-- Slimscroll -->
<script src="<?php echo e(url('')); ?>/bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="<?php echo e(url('')); ?>/bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo e(url('')); ?>/dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo e(url('')); ?>/dist/js/demo.js"></script>
<!-- page script -->
<script>
  setTimeout(function() {
      $('#delay3s').fadeOut('fast');
  }, 2000);
  var text = new Array();
  var dem = '';
  function allclick() {
    for (var i = 0; i < 20; i++) {
      document.getElementsByName('trclick')[i].click();
    }
  }
  function checkbox(id) {
    var check = document.getElementById("checkbox"+id).innerHTML;
    soluong = text.length;
    if (check == '<span class="fa fa-square-o"></span>') {
      text[soluong]=id;
      document.getElementById('nhanbox').value = text;
      document.getElementById("checkbox"+id).innerHTML = "<span class='fa fa-check'></span>";
      document.getElementById("checkbox"+id).style.color='red';
    }else{
      var deleteElement = id;
      var i = text.indexOf(deleteElement);
      if (i != -1) {
          text.splice(i,1);
      }
      document.getElementById('nhanbox').value = text;
      document.getElementById("checkbox"+id).innerHTML = "<span class='fa fa-square-o'></span>";
      document.getElementById("checkbox"+id).style.color='#00a65a';
    }
  }
  function submitform() {
    optionnv = document.getElementById('optionnv').value;
    document.getElementById('nhanbox2').value = optionnv;
    document.getElementById('formtrangthai').submit();
  }
  $(function () {
    $('#example1').DataTable()
  })
</script>
</body>
</html>

<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">
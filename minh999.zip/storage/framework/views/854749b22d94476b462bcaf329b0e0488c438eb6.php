<?php echo $__env->make('teamplte.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('teamplte.slidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<style type="text/css">
  .direct-chat-messages {
    height: 365px;
  }
  .callout.callout-success {
    background-color: #00a65a !important;
  }
  .profile-user-img {
    margin: 0 auto;
    width: 100%;
    max-width: 150px;
    border:  #fff;
    border-radius: 5%;
  }
</style>
<link rel="stylesheet" href="bower_components/morris.js/morris.css">
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Thông tin cá nhân
        <small>Chúc mừng năm mới</small>
      </h1>
    </section>

    <!-- Main content -->
    <section class="content">
<?php if( session()->has('message') ): ?>
      <div class="callout callout-success" id="taban">
        <h4>Thông báo!</h4>
        <p> <?php echo e(session()->get('message')); ?></p>
      </div>
<?php endif; ?>
      <div class="row">
        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $idprofile = $user->id; ?>
        <div class="col-md-3">

          <!-- Profile Image -->
          <div class="box box-primary">
            <div class="box-body box-profile">
              <img class="profile-user-img img-responsive " src="<?php echo e(url('public/avatar')); ?>/<?php echo e($user->avatar); ?>" alt="User profile picture">

              <h3 class="profile-username text-center"><?php echo e($user->hoten); ?></h3>

              <p class="text-muted text-center">
                <?php $__currentLoopData = $chucvu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chucvu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($user->rule == $chucvu->id): ?>
                <?php echo e($chucvu->name); ?>

                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </p>
            </div>
            <div class="box-body">
              <strong><i class="fa fa-book margin-r-5"></i> Số điện thoại</strong>

              <p class="text-muted">
                <?php echo e($user->sdt); ?>

              </p>

              <hr>

              <strong><i class="fa fa-google margin-r-5"></i> Email</strong>

              <p class="text-muted">
                <?php echo e($user->email); ?>

              </p>

              <hr>

              <strong><i class="fa fa-map-marker margin-r-5"></i> Địa chỉ</strong>

              <p class="text-muted"><?php echo e($user->diachi); ?></p>

              <hr>

              <strong><i class="fa fa-file-text-o margin-r-5"></i> Ghi chú</strong>

              <p><?php echo e($user->mota); ?></p>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- xxx -->
        <div class="col-md-9">
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <li class="active"><a href="#activity" data-toggle="tab" aria-expanded="true">Để lại bình luận</a></li>
              <!-- <li class=""><a href="#timeline" data-toggle="tab" aria-expanded="false">Công việc</a></li> -->
              <?php if(Auth::user()->id == $user->id && Auth::user()->rule != 7): ?>
              <li class=""><a href="#settings" data-toggle="tab" aria-expanded="false">Cài đặt</a></li>
              <?php endif; ?>
            </ul>
            <div class="tab-content">
              <div class="tab-pane active" id="activity">
                <!-- comment -->
                <div class="chat-box">
                  <!-- DIRECT CHAT PRIMARY -->
                  <div class="box box-primary direct-chat direct-chat-primary">
                    <div class="box-header with-border">
                      <h3 class="box-title">Bình luận</h3>

                      <div class="box-tools pull-right">
                        <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                        </button>
                      </div>
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body">
                      <!-- Conversations are loaded here -->
                      <div class="direct-chat-messages">
                  <?php $__currentLoopData = $comment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if($comment->iduser == Auth::user()->id): ?>
                  <div class="direct-chat-msg right">
                    <div class="direct-chat-info clearfix">
                      <span class="direct-chat-name pull-right">
                      <?php else: ?>
                  <div class="direct-chat-msg Left">
                    <div class="direct-chat-info clearfix">
                      <span class="direct-chat-name pull-left">
                      <?php endif; ?>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $us): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($us->id == $comment->iduser): ?>
                        <?php echo e($us->hoten); ?>

                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </span>
                      <?php if($comment->iduser == Auth::user()->id): ?>
                      <span class="direct-chat-timestamp pull-left"><?php echo e($comment->created_at); ?></span>
                      <?php else: ?>
                      <span class="direct-chat-timestamp pull-right"><?php echo e($comment->created_at); ?></span>
                      <?php endif; ?>
                    </div>
                    <!-- /.direct-chat-info -->
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $us): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($us->id == $comment->iduser): ?>
                    <img class="direct-chat-img" src="<?php echo e(url('public/avatar')); ?>/<?php echo e($us->avatar); ?>" alt="Message User Image">
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <!-- /.direct-chat-img -->
                    <div class="direct-chat-text">
                      <?php echo e($comment->noidung); ?>

                    </div>
                    <!-- /.direct-chat-text -->
                  </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </div>
                      <!--/.direct-chat-messages-->
                    </div>
                    <!-- /.box-body -->
                    <div class="box-footer">
                      <form action="<?php echo e(route('pustcomment')); ?>" method="post">
                        <div class="input-group">
                          <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                          <input type="hidden" name="idpost" value="mem<?php echo e($idprofile); ?>">
                          <input type="hidden" name="iduser" value="<?php echo e(Auth::user()->id); ?>">
                          <input type="text" name="message" placeholder="Type Message ..." class="form-control">
                              <span class="input-group-btn">
                                <button type="submit" class="btn btn-primary btn-flat">Send</button>
                              </span>
                        </div>
                      </form>
                    </div>
                    <!-- /.box-footer-->
                  </div>
                  <!--/.direct-chat -->
                </div>
                <!-- end comment -->
              </div>
              <!-- /.tab-pane -->
              <!-- <div class="tab-pane" id="timeline">
                <div class="">
                  <div class="box-header">
                    <h3 class="box-title">Hợp đồng vay tiền</h3>
                  </div>
                  <div class="box-body table-responsive no-padding">
                    <table class="table table-hover">
                      <tbody><tr>
                        <th>STT</th>
                        <th>Ngày</th>
                        <th>Số ngày</th>
                        <th>Tiền lãi</th>
                        <th>Tiền khác</th>
                        <th>Tổng lãi</th>
                        <th>Tiền khách trả</th>
                        <th>Tình trạng</th>
                      </tr>
                      <tr>
                        <td>1</td>
                        <td>5-2-2018</td>
                        <td>7</td>
                        <td>900.000 VNĐ</td>
                        <td>0 VNĐ</td>
                        <td>900.000 VNĐ</td>
                        <td>900.000 VNĐ</td>
                        <td><span class="label label-danger">Chưa thanh toán</span></td>
                        <td><a href="#">Chi tiết</a></td>
                      </tr>
                      <tr>
                        <td>1</td>
                        <td>12-2-2018</td>
                        <td>7</td>
                        <td>900.000 VNĐ</td>
                        <td>0 VNĐ</td>
                        <td>900.000 VNĐ</td>
                        <td>900.000 VNĐ</td>
                        <td><span class="label label-success">Đã thanh toán</span></td>
                        <td><a href="#">Chi tiết</a></td>
                      </tr>
                      <tr>
                        <td>1</td>
                        <td>19-2-2018</td>
                        <td>7</td>
                        <td>900.000 VNĐ</td>
                        <td>0 VNĐ</td>
                        <td>900.000 VNĐ</td>
                        <td>900.000 VNĐ</td>
                        <td><span class="label label-warning">Chưa thanh toán</span></td>
                        <td><a href="#">Chi tiết</a></td>
                      </tr>
                      <tr>
                        <td>1</td>
                        <td>26-2-2018</td>
                        <td>7</td>
                        <td>900.000 VNĐ</td>
                        <td>0 VNĐ</td>
                        <td>900.000 VNĐ</td>
                        <td>900.000 VNĐ</td>
                        <td><span class="label label-warning">Chưa thanh toán</span></td>
                        <td><a href="#">Chi tiết</a></td>
                      </tr>
                      <tr>
                        <td>1</td>
                        <td>19-2-2018</td>
                        <td>7</td>
                        <td>900.000 VNĐ</td>
                        <td>0 VNĐ</td>
                        <td>900.000 VNĐ</td>
                        <td>900.000 VNĐ</td>
                        <td><span class="label label-warning">Chưa thanh toán</span></td>
                        <td><a href="#">Chi tiết</a></td>
                      </tr>
                    </tbody></table>
                  </div>
                </div>
              </div> -->
              <!-- /.tab-pane -->
              <?php if(Auth::user()->id == $user->id && Auth::user()->rule != 7): ?>
              <div class="tab-pane" id="settings">
                <div class="box-body">
                  <div class="box-group" id="accordion">
                    <!-- we are adding the .panel class so bootstrap.js collapse plugin detects it -->
                    <div class="panel box box-primary">
                      <div class="box-header with-border">
                        <h4 class="box-title">
                          <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" class="">
                            Ảnh đại diện
                          </a>
                        </h4>
                      </div>
                      <div id="collapseOne" class="panel-collapse collapse in" aria-expanded="true" style="">
                        <div class="box-body">
                          <form role="form" method="post" action="<?php echo e(route('thayavatar')); ?>" enctype="multipart/form-data">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <div class="box-body">
                              <div class="form-group">
                                <label for="exampleInputFile">File ảnh</label>
                                <input type="file" id="exampleInputFile" name="myfile">
                                <p class="help-block">Giới hạn dung lượng file 2mb</p>
                                <input type="hidden" name="id" value="<?php echo e(Auth::user()->id); ?>">
                              </div>
                            </div>

                            <div class="box-footer">
                              <button type="submit" class="btn btn-primary">Chỉnh sửa</button>
                            </div>
                          </form>
                        </div>
                      </div>
                    </div>
                    <div class="panel box box-success">
                      <div class="box-header with-border">
                        <h4 class="box-title">
                          <a data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" class="collapsed" aria-expanded="false">
                            Thông tin cá nhân
                          </a>
                        </h4>
                      </div>
                      <div id="collapseTwo" class="panel-collapse collapse" aria-expanded="false" style="height: 0px;">
                        <div class="box-body">
                          <form role="form" method="POST" action="<?php echo e(route('thaythongtincanhan')); ?>">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <input type="hidden" name="id" value="<?php echo e($user->id); ?>">
                            <div class="box-body">
                              <div class="form-group">
                                <label >Họ tên</label>
                                <input type="text" name="hoten" class="form-control" value="<?php echo e($user->hoten); ?>">
                              </div>
                              <div class="form-group">
                                <label >Số điện thoại</label>
                                <input type="text" class="form-control" name="sdt" value="<?php echo e($user->sdt); ?>">
                              </div>
                              <div class="form-group">
                                <label >Email</label>
                                <input type="text" class="form-control" disabled="" value="<?php echo e($user->email); ?>">
                              </div>
                              <div class="form-group">
                                <label >Địa chỉ</label>
                                <input type="text" class="form-control"  name="diachi" value="<?php echo e($user->diachi); ?>">
                              </div>
                              <div class="form-group">
                                <label >Mô tả ngắn</label>
                                <input type="text" class="form-control"  name="motangan" value="<?php echo e($user->mota); ?>">
                              </div>
                            </div>
                            <div class="box-footer">
                              <button type="submit" class="btn btn-primary">Chỉnh sửa</button>
                            </div>
                          </form>
                        </div>
                      </div>
                    </div>
                    <div class="panel box box-danger">
                      <div class="box-header with-border">
                        <h4 class="box-title">
                          <a data-toggle="collapse" data-parent="#accordion" href="#collapseThree" class="collapsed" aria-expanded="false">
                            Mật khẩu
                          </a>
                        </h4>
                      </div>
                      <div id="collapseThree" class="panel-collapse collapse" aria-expanded="false" style="height: 0px;">
                        <div class="box-body">
                          <form role="form" action="<?php echo e(route('doimatkhau')); ?>" method="post">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <div class="box-body">
                              <input type="hidden" name="id" value="<?php echo e($user->id); ?>">
                              <div class="form-group">
                                <label for="exampleInputPassword1">Mật khẩu</label>
                                <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password" name="password1">
                              </div>
                              <div class="form-group">
                                <label for="exampleInputPassword1">Nhập lại mật khẩu</label>
                                <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password" name="password2">
                              </div>
                            </div>
                            <!-- /.box-body -->

                            <div class="box-footer">
                              <button type="submit" class="btn btn-primary">Chỉnh sửa</button>
                            </div>
                          </form>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <?php endif; ?>
              <!-- /.tab-pane -->
            </div>
            <!-- /.tab-content -->
          </div>
          <!-- /.nav-tabs-custom -->
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </section>
    <!-- /.content -->
  </div>
<script type="text/javascript">
setTimeout(function() {
    $('#taban').fadeOut('fast');
}, 2000);
</script>
<?php echo $__env->make('teamplte.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

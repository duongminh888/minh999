<?php echo $__env->make('teamplte.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <!-- Left side column. contains the logo and sidebar -->
<?php echo $__env->make('teamplte.slidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Hello shop!.. 
      </h1>
    </section>

    <!-- Main content -->
    <section class="content">
    <?php if(Auth::user()->rule == 7): ?>
      <div class="row">
        <div class="container" style="width: 100%">

          <div class="col-md-6">
            <div class="box box-primary">
              <div class="box-header with-border">
                <h3 class="box-title">Thêm đơn vay</h3>
              </div>
              <!-- /.box-header -->
              <!-- form start -->
              <form role="form" action="<?php echo e(route('shopadddonvay')); ?>" method="post" enctype="multipart/form-data">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                <div class="box-body">
                  <?php if( session()->has('thongbao') ): ?>
                    <div id="delay3s" class="alert alert-success alert-dismissible" style="    background-color: #00a65a !important;">
                      <b><i class="icon fa fa-check"></i> Thông báo!</b> <?php echo e(session()->get('thongbao')); ?>

                    </div>
                  <?php endif; ?>
                  <?php if( session()->has('canhbao') ): ?>
                    <div id="delay3s" class="alert alert-danger alert-dismissible" >
                      <b><i class="icon fa fa-check"></i> Thông báo!</b> <?php echo e(session()->get('canhbao')); ?>

                    </div>
                  <?php endif; ?>
                  <div class="form-group <?php if($errors->first('hoten')): ?>  has-error <?php endif; ?>">
                    <label>Họ tên</label>
                    <input type="text" class="form-control" id="<?php if($errors->first('hoten')): ?> inputError <?php endif; ?>" name="hoten" placeholder="Họ tên">
                    <span class="help-block" style="color: red"><?php echo $errors->first('hoten'); ?></span>
                  </div>
                  <div class="form-group  <?php if($errors->first('cmt')): ?>  has-error <?php endif; ?>">
                    <label>Số chứng minh thư</label>
                    <input type="number" class="form-control" id="<?php if($errors->first('cmt')): ?> inputError <?php endif; ?>" name="cmt" placeholder="Số chứng minh thư">
                    <span class="help-block" style="color: red"><?php echo $errors->first('cmt'); ?></span>
                  </div>
                  <div class="form-group  <?php if($errors->first('sdt')): ?>  has-error <?php endif; ?>">
                    <label>Số điện thoại</label>
                    <input type="number" class="form-control" id="<?php if($errors->first('sdt')): ?> inputError <?php endif; ?>" name="sdt" placeholder="Số điện thoại">
                    <span class="help-block" style="color: red"><?php echo $errors->first('sdt'); ?></span>
                  </div>
                  <div class="form-group  <?php if($errors->first('sotien')): ?>  has-error <?php endif; ?>">
                    <label>Số tiền</label>
                    <input type="number" class="form-control" id="<?php if($errors->first('sotien')): ?> inputError <?php endif; ?>" name="sotien" placeholder="Số tiền">
                    <span class="help-block" style="color: red"><?php echo $errors->first('sotien'); ?></span>
                  </div>
                  <div class="form-group  <?php if($errors->first('songayvay')): ?>  has-error <?php endif; ?>">
                    <label>Số ngày vay</label>
                    <input type="number" class="form-control" id="<?php if($errors->first('songayvay')): ?> inputError <?php endif; ?>" name="songayvay" placeholder="Số ngày vay">
                    <span class="help-block" style="color: red"><?php echo $errors->first('songayvay'); ?></span>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputFile">Các file thông tin khác</label>
                    <input type="file" id="exampleInputFile" name="myfile">
                    <p class="help-block">Giới hạn file tải lên 5mb.</p>
                    <?php echo $errors->first('myfile'); ?>
                    <span class="help-block" style="color: red"><?php echo $errors->first('myfile'); ?></span>
                  </div>
                </div>
                <!-- /.box-body -->

                <div class="box-footer">
                  <button type="submit" class="btn btn-primary">Hoàn thành</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    <?php else: ?>
      <div class="callout callout-danger">
        <h4>Lỗi!</h4>

        <p>Trang web này dành riêng cho tài khoản shop.</p>
      </div>
    <?php endif; ?>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php echo $__env->make('teamplte.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
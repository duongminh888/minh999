<?php echo $__env->make('teamplte.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <!-- DataTables -->
  <style type="text/css">
    #example1_filter {
      float: right;
    }
    #example1_paginate {
      text-align: right;
    }
    #example1_paginate .pagination {
      margin: 0px;
    }
    td {
      width: 50%;
    }
  </style>
  <!-- Left side column. contains the logo and sidebar -->
<?php echo $__env->make('teamplte.slidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <link rel="stylesheet" href="bower_components/morris.js/morris.css">
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Đơn xin vay
        <small>Chúc mừng năm mới</small>
      </h1>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-12">
          <div class="box box-success">
            <div class="box-header with-border">
              <h3 class="box-title">Thông tin user: </h3>
              <?php if(auth::user()->rule < 3): ?>
              <div class="box-tools pull-right">
                <a href="<?php echo e(url('themthanhvien')); ?>">
                  <button type="button" class="btn-box-tool btn"><i class="fa  fa-check"></i> Thêm thành viên</button>
                </a>
<!--                 <button type="button" class="btn-box-tool btn" onclick="hienavatar()">Avatar</button> -->
              </div>
              <?php endif; ?>
            </div>
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
              <table class="table table-striped">
                <thead>
                  <tr>
                    <th></th>
                    <th>Tên</th>
                    <th>Email</th>
                    <th style="min-width: 150px">Phòng giao dịch</th>
                    <th style="min-width: 200px">Chức vụ</th>
                    <th>#</th>
                  </tr>
                </thead>
                <tbody >
                  <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr id="hang<?php echo e($user->id); ?>" onmouseover="hang(<?php echo e($user->id); ?>)" onmouseout="hang2(<?php echo e($user->id); ?>)">
                    <td>
                      <a id="loi<?php echo e($user->id); ?>" href="<?php echo e(url('profile')); ?>/<?php echo e($user->name); ?>" name="avatar" >
                        <img src="<?php echo e(url('public/avatar')); ?>/<?php echo e($user->avatar); ?>" width="70" height="70">
                      </a>
                    </td>
                    <td><a href="<?php echo e(url('profile')); ?>/<?php echo e($user->name); ?>"><b><?php echo e($user->name); ?></b></a></td>
                    <td><?php echo e($user->email); ?></td>
                    <td style="width: 100px">
                      <?php $__currentLoopData = $phonggiaodich; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pgd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if($pgd->id == $user->phong || $pgd->giamdoc == $user->id): ?>
                        <?php echo e($pgd->name); ?>

                      <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                    <td>
                      <p style="font-weight: bold;margin: 0px 20px 0px 0px">
                        <?php $__currentLoopData = $chucvu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($cv->id == $user->rule): ?>
                        <?php echo e($cv->name); ?>

                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </p>
                    </td>
                    <?php if(Auth::user()->rule < 3): ?>
                    <td>
                      <a href="<?php echo e(url('editmember')); ?>/<?php echo e($user->id); ?>">
                        <i class="fa fa-edit" style="font-size: 22px"></i> 
                      </a>
                    </td>
                    <?php endif; ?>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
        </div>
        <div class="col-md-6">
            <!-- <div class="box box-primary">
              <div class="box-header with-border">
                <h3 class="box-title">Thông tin khách hàng: </h3>
              </div>
              <div class="box-body table-responsive no-padding">
                <table class="table table-hover">
                  <tbody>
                    <tr>
                      <th>Họ tên khách hàng</th>
                      <th>Dương Văn Minh</th>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div> -->
        </div>
      </div>
    </section>
    <!-- /.content -->
  </div>
  <script type="text/javascript">
    dem = 0;
    // // function hienavatar() {
    // //   demavatar = document.getElementsByName("avatar").length;
    // //   if(dem==0){
    // //     for (var i = 0; i <demavatar; i++) {
    // //       document.getElementsByName('avatar')[i].style.display = 'block';
    // //     }
    // //     dem = 1;
    // //   }else{
    // //     for (var i = 0; i <demavatar; i++) {
    // //       document.getElementsByName('avatar')[i].style.display = 'none';
    // //     }
    // //     dem = 0;
    // //   }
    // // }
    // function hang(id) {
    //   if(dem == 0)
    //   document.getElementById('loi'+id).style.display = 'block';
    // }
    // function hang2(id) {
    //   if(dem == 0)
    //   document.getElementById('loi'+id).style.display = 'none';
    // }
  </script>
<?php echo $__env->make('teamplte.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class shophoso extends Model
{
    protected $table = 'shophoso';
    //
}

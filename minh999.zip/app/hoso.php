<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class hoso extends Model
{
    //
    protected $table = 'hoso';
}

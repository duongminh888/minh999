<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class nhanvien_pgd extends Model
{
    protected $table = 'nhanvien_pgd';
}

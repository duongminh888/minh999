<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class trangthaihoso extends Model
{
    protected $table = 'trangthaihoso';
}

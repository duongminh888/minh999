<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class loaivay extends Model
{
    protected $table = 'loaivay';
    //
}

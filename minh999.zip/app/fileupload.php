<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class fileupload extends Model
{
    protected $table = 'fileupload';
    //
}

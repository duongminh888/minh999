<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class nhanvien_donvay extends Model
{
    protected $table = 'nhanvien_donvay';
    //
    // public function hoso()
    // {
    // 	return $this->belongsTo('App/hoso','idhoso','id');
    // }
}

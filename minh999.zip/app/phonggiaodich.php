<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class phonggiaodich extends Model
{
    protected $table = 'phonggiaodich';
    //
}
